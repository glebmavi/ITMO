class A {
  int t26;
  int t9;
  int t11;
  int t33;
  int t12;
  long t4;
  long t27;
  long t19;
  int[] t18 = {-3, -1, -3, -3};
  int[] t14 = {-1, 2, 0, -3};
  int[] t21 = {1, 2, 3, -3, -2};
  static int t17;
  static int t29;
  static int t8;
  static int t1;
  static int t31;
  public A() {
    t26 = 0;
    t9 = 3;
    t11 = 5;
    t33 = 8;
    t12 = 0;
    t4 = 9L;
    t27 = 6L;
    t19 = 3L;
  }
  public void t30() {
    System.out.println("метод t30 в классе A");
    System.out.println(t11 << 1);
  }
  public void t36() {
    System.out.println("метод t36 в классе A");
    System.out.println(t26 >> 1);
  }
  public void t34() {
    System.out.println("метод t34 в классе A");
    System.out.println(--t31);
  }
  public void t7() {
    System.out.println("метод t7 в классе A");
    System.out.println(t18[1] + t18[1]);
  }
  public void t5() {
    System.out.println("метод t5 в классе A");
    System.out.println(t14[1]);
  }
  public void t22() {
    System.out.println("метод t22 в классе A");
    System.out.println(t14[2] + t14[2]);
  }
  public static void t32() {
    System.out.println("метод t32 в классе A");
    System.out.println(t1);
  }
  public static void t38() {
    System.out.println("метод t38 в классе A");
    System.out.println((t1 - 4));
  }
  public static void t3() {
    System.out.println("метод t3 в классе A");
    System.out.println(t31);
  }
  public static void t20() {
    System.out.println("метод t20 в классе A");
    System.out.println((t31 + 1));
  }
  public void t10(A r) {
    r.t30();
  }
  public void t10(B r) {
    r.t36();
  }
}
