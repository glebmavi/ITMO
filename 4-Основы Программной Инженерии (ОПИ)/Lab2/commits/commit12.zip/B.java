class B extends A {
  public B() {
    t26 = 7;
    t11 = 5;
    t33 = 4;
    t12 = 7;
    t4 = 3L;
  }
  public void t30() {
    System.out.println("метод t30 в классе B");
    System.out.println(t18[2] - t18[1]);
  }
  public void t7() {
    System.out.println("метод t7 в классе B");
    System.out.println(t21[1]);
  }
  public static void t32() {
    System.out.println("метод t32 в классе B");
    System.out.println(t17);
  }
  public static void t38() {
    System.out.println("метод t38 в классе B");
    System.out.println((t17 - 3));
  }
  public static void t3() {
    System.out.println("метод t3 в классе B");
    System.out.println(t17--);
  }
  public static void t20() {
    System.out.println("метод t20 в классе B");
    System.out.println(t29);
  }
  public void t10(A r) {
    r.t34();
  }
  public void t10(B r) {
    r.t7();
  }
}
