// var. 340991
public class Lab4 {
  public static void main(String[] args) {
  A a = new A();
  A b = new B();
  B c = new B();
  c.t30();
  a.t36();
  b.t34();
  a.t7();
  a.t5();
  b.t22();
  c.t32();
  b.t38();
  b.t3();
  c.t20();
  b.t10(a);
  a.t10(b);
  b.t10(c);
  }
}
previous : 19
